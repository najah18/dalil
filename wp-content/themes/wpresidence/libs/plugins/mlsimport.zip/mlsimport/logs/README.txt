logs are per day and per action
delete the ones you don't need